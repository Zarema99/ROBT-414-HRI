README file for ROBT414 Programming Assignment 1 by Zarema Balgabekova

INTRODUCTION
---------------------------------------------------------------------------------------------------------------------------
The purpose of the program is to recognize three postures of emotions based on keypoints obtained with the OpenPose library.
Additionaly, it should print the statistics of the number and duration of postures.

For posture recognition, I chose happy, neutral, and sad postures. The corresponding video is a part of submission.
My video also contains surprise and disgust postures. They should be recognized as garbage. 
Some postures between the chosen postures (happy, sad, neutral) are also considered as garbage because we do not change postures at once.
Key points positions were obtained with the help of video_parse.py, and then they were combined into CSV file using to_format.py. The corresponding CSV file is a part of submission.
The algorithm for posture recognition is based on the comparison of distances between keypoints. 
Some useful distances are distance betwen shoulders, elbows, wrists, distance between face and neck, etc.
CSV file with obtained distances is a part of submission.

REQUIREMENTS
---------------------------------------------------------------------------------------------------------------------------
OpenPose Library
The program is written in Python.
The only Python libraries that are used in the program are pandas (used to extract data from CSV file) and numpy (used to calculate distances between points).

TROUBLESHOOTING
---------------------------------------------------------------------------------------------------------------------------
It may be needed to change the path of the CSV file with keypoints.

